package com.ele.learn;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version V1.0
 * @Package com.ele.learn
 * @Description: (用一句话描述该文件做什么)
 * @author: 似流水
 * @date: 2019/02/23 18:15
 */
@RestController
public class DemoController {
    @Autowired
    public DemoFeignService demoFeignService;

    @RequestMapping("/test")
    public String test() {
        return demoFeignService.test("test");
    }

    @RequestMapping("/user")
    public User user() {
        User user = new User();
        user.setAge(10);
        user.setName("Joab-Y");
        return demoFeignService.user(user);
    }
}