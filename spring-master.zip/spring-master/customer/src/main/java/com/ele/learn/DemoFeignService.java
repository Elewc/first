package com.ele.learn;

import org.springframework.cloud.openfeign.FeignClient;

/**
 * @version V1.0
 * @Package com.ele.learn
 * @Description: (用一句话描述该文件做什么)
 * @author: 似流水
 * @date: 2019/02/23 18:14
 */
// name: 服务者application.yml中的spring.application.name
// fallback: 断路器执行方法，即方法执行失败调用
@FeignClient(name="demo-provider", fallback = DemoServiceFallback.class)
public interface DemoFeignService extends IDemoApi {
}