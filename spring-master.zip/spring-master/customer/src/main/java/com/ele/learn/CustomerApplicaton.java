package com.ele.learn;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

/**
 * @version V1.0
 * @Package com.ele.learn
 * @Description: (用一句话描述该文件做什么)
 * @author: 似流水
 * @date: 2019/02/23 18:15
 */
@SpringBootApplication
@EnableEurekaClient
@EnableDiscoveryClient
@EnableFeignClients
public class CustomerApplicaton {
    public static void main(String[] args) {
        SpringApplication.run(CustomerApplicaton.class, args);
    }
}