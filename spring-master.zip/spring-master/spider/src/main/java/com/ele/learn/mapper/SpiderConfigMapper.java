package com.ele.learn.mapper;

import com.ele.learn.entity.SpiderConfig;

public interface SpiderConfigMapper {
    int deleteByPrimaryKey(Integer sitId);

    int insert(SpiderConfig record);

    int insertSelective(SpiderConfig record);

    SpiderConfig selectByPrimaryKey(Integer sitId);

    int updateByPrimaryKeySelective(SpiderConfig record);

    int updateByPrimaryKey(SpiderConfig record);
}