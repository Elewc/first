package com.ele.learn.entity;

public class SpiderConfig {
    private Integer sitId;

    private String sitName;

    private String sitUrl;

    private String templateUrl;

    private String resourceListSelect;

    private String titleSelect;

    private String resourceSelect;

    private String https;

    private String titleFilter;

    public SpiderConfig(Integer sitId, String sitName, String sitUrl, String templateUrl, String resourceListSelect, String titleSelect, String resourceSelect, String https, String titleFilter) {
        this.sitId = sitId;
        this.sitName = sitName;
        this.sitUrl = sitUrl;
        this.templateUrl = templateUrl;
        this.resourceListSelect = resourceListSelect;
        this.titleSelect = titleSelect;
        this.resourceSelect = resourceSelect;
        this.https = https;
        this.titleFilter = titleFilter;
    }

    public SpiderConfig() {
        super();
    }

    public Integer getSitId() {
        return sitId;
    }

    public void setSitId(Integer sitId) {
        this.sitId = sitId;
    }

    public String getSitName() {
        return sitName;
    }

    public void setSitName(String sitName) {
        this.sitName = sitName == null ? null : sitName.trim();
    }

    public String getSitUrl() {
        return sitUrl;
    }

    public void setSitUrl(String sitUrl) {
        this.sitUrl = sitUrl == null ? null : sitUrl.trim();
    }

    public String getTemplateUrl() {
        return templateUrl;
    }

    public void setTemplateUrl(String templateUrl) {
        this.templateUrl = templateUrl == null ? null : templateUrl.trim();
    }

    public String getResourceListSelect() {
        return resourceListSelect;
    }

    public void setResourceListSelect(String resourceListSelect) {
        this.resourceListSelect = resourceListSelect == null ? null : resourceListSelect.trim();
    }

    public String getTitleSelect() {
        return titleSelect;
    }

    public void setTitleSelect(String titleSelect) {
        this.titleSelect = titleSelect == null ? null : titleSelect.trim();
    }

    public String getResourceSelect() {
        return resourceSelect;
    }

    public void setResourceSelect(String resourceSelect) {
        this.resourceSelect = resourceSelect == null ? null : resourceSelect.trim();
    }

    public String getHttps() {
        return https;
    }

    public void setHttps(String https) {
        this.https = https == null ? null : https.trim();
    }

    public String getTitleFilter() {
        return titleFilter;
    }

    public void setTitleFilter(String titleFilter) {
        this.titleFilter = titleFilter == null ? null : titleFilter.trim();
    }
}