package com.ele.learn.entity;

public class Image {
    private Integer imageId;

    private String imageName;

    private String imageUrl;

    private Integer imageModuleId;

    private String imageModuleName;

    private String imageDown;

    public Image(Integer imageId, String imageName, String imageUrl, Integer imageModuleId, String imageModuleName, String imageDown) {
        this.imageId = imageId;
        this.imageName = imageName;
        this.imageUrl = imageUrl;
        this.imageModuleId = imageModuleId;
        this.imageModuleName = imageModuleName;
        this.imageDown = imageDown;
    }

    public Image() {
        super();
    }

    public Integer getImageId() {
        return imageId;
    }

    public void setImageId(Integer imageId) {
        this.imageId = imageId;
    }

    public String getImageName() {
        return imageName;
    }

    public void setImageName(String imageName) {
        this.imageName = imageName == null ? null : imageName.trim();
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl == null ? null : imageUrl.trim();
    }

    public Integer getImageModuleId() {
        return imageModuleId;
    }

    public void setImageModuleId(Integer imageModuleId) {
        this.imageModuleId = imageModuleId;
    }

    public String getImageModuleName() {
        return imageModuleName;
    }

    public void setImageModuleName(String imageModuleName) {
        this.imageModuleName = imageModuleName == null ? null : imageModuleName.trim();
    }

    public String getImageDown() {
        return imageDown;
    }

    public void setImageDown(String imageDown) {
        this.imageDown = imageDown == null ? null : imageDown.trim();
    }
}