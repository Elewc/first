package com.ele.learn.entity;

public class Module {
    private Integer moduleId;

    private String moduleName;

    private Integer totalPage;

    private Integer sitId;

    private String sitName;

    public Module(Integer moduleId, String moduleName, Integer totalPage, Integer sitId, String sitName) {
        this.moduleId = moduleId;
        this.moduleName = moduleName;
        this.totalPage = totalPage;
        this.sitId = sitId;
        this.sitName = sitName;
    }

    public Module() {
        super();
    }

    public Integer getModuleId() {
        return moduleId;
    }

    public void setModuleId(Integer moduleId) {
        this.moduleId = moduleId;
    }

    public String getModuleName() {
        return moduleName;
    }

    public void setModuleName(String moduleName) {
        this.moduleName = moduleName == null ? null : moduleName.trim();
    }

    public Integer getTotalPage() {
        return totalPage;
    }

    public void setTotalPage(Integer totalPage) {
        this.totalPage = totalPage;
    }

    public Integer getSitId() {
        return sitId;
    }

    public void setSitId(Integer sitId) {
        this.sitId = sitId;
    }

    public String getSitName() {
        return sitName;
    }

    public void setSitName(String sitName) {
        this.sitName = sitName == null ? null : sitName.trim();
    }
}