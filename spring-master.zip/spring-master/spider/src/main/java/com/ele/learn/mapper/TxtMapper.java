package com.ele.learn.mapper;

import com.ele.learn.entity.Txt;

public interface TxtMapper {
    int deleteByPrimaryKey(Integer txtId);

    int insert(Txt record);

    int insertSelective(Txt record);

    Txt selectByPrimaryKey(Integer txtId);

    int updateByPrimaryKeySelective(Txt record);

    int updateByPrimaryKey(Txt record);
}