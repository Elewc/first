package com.ele.learn.entity;

public class Txt {
    private Integer txtId;

    private String txtName;

    private String txtUrl;

    private Integer txtModuleId;

    private String txtIsDown;

    private String txtModuleName;

    public Txt(Integer txtId, String txtName, String txtUrl, Integer txtModuleId, String txtIsDown, String txtModuleName) {
        this.txtId = txtId;
        this.txtName = txtName;
        this.txtUrl = txtUrl;
        this.txtModuleId = txtModuleId;
        this.txtIsDown = txtIsDown;
        this.txtModuleName = txtModuleName;
    }

    public Txt() {
        super();
    }

    public Integer getTxtId() {
        return txtId;
    }

    public void setTxtId(Integer txtId) {
        this.txtId = txtId;
    }

    public String getTxtName() {
        return txtName;
    }

    public void setTxtName(String txtName) {
        this.txtName = txtName == null ? null : txtName.trim();
    }

    public String getTxtUrl() {
        return txtUrl;
    }

    public void setTxtUrl(String txtUrl) {
        this.txtUrl = txtUrl == null ? null : txtUrl.trim();
    }

    public Integer getTxtModuleId() {
        return txtModuleId;
    }

    public void setTxtModuleId(Integer txtModuleId) {
        this.txtModuleId = txtModuleId;
    }

    public String getTxtIsDown() {
        return txtIsDown;
    }

    public void setTxtIsDown(String txtIsDown) {
        this.txtIsDown = txtIsDown == null ? null : txtIsDown.trim();
    }

    public String getTxtModuleName() {
        return txtModuleName;
    }

    public void setTxtModuleName(String txtModuleName) {
        this.txtModuleName = txtModuleName == null ? null : txtModuleName.trim();
    }
}