package com.ele.learn.controller;

import com.ele.learn.mapper.ModuleMapper;
import com.ele.learn.entity.Module;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version V1.0
 * @Package com.ele.learn.controller
 * @Description: (用一句话描述该文件做什么)
 * @author: 似流水
 * @date: 2019/03/13 23:30
 */
@RestController
public class SpiderController {

    @Autowired
    private ModuleMapper moduleMapper;

    @RequestMapping("/hello")
    public String index() {

        Module module = moduleMapper.selectByPrimaryKey(1);

        return "Hello SpringBoot"+module.getModuleName();

    }

}