package com.ele.learn;

/**
 * @version V1.0
 * @Package com.ele.learn
 * @Description: (用一句话描述该文件做什么)
 * @author: 似流水
 * @date: 2019/03/13 23:28
 */

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@SpringBootApplication
@EnableSwagger2
@MapperScan("com.ele.learn.mapper")
public class SpiderApplication {
    public static void main(String[] args) {
        SpringApplication.run(SpiderApplication.class, args);
    }
}
