package com.ele.learn;

import java.io.Serializable;

/**
 * @version V1.0
 * @Title: ${file_name}
 * @Package ${package_name}
 * @Description: ${todo}(用一句话描述该文件做什么)
 * @author: 似流水
 * @date: ${date} ${time}
 */
public class User implements Serializable {

    private static final long serialVersionUID = 1L;

    private int age;

    private String name;

    public int getAge() {
        return age;
    }

    public User(){}

    public User(int age, String name){
        this.age = age;
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
