package com.ele.learn;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

/**
 * @version V1.0
 * @Package com.ele.learn
 * @Description: (用一句话描述该文件做什么)
 * @author: 似流水
 * @date: 2019/02/23 17:57
 */
@RestController
public class DemoProvider implements IDemoApi {
    @Override
    public String test(String test) {
        return "test: " + test;
    }

    @Override
    public User user(@RequestBody User user) {
        if (user == null) {
            user = new User(10, "Joab-Y");
        }
        return user;
    }

}